---
agent: speckit.constitution
---
